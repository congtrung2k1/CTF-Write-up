#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <cstdlib>
#include <unistd.h>
#include <cstdio>
#include <memory>
#include <string>
#include <seccomp.h>
#include <linux/seccomp.h>
#include "sandbox_protocol.h"
#include "sandbox_lib.h"

using namespace std;

SandboxAPI::~SandboxAPI()
{
	if(m_sock_fd != -1){
		close(m_sock_fd);
	}
}

void SandboxAPI::init_sandbox()
{
	shared_ptr<SandboxCommand> command = make_shared<SandboxCommand>(GET_ROOT_DIR, 0);
	shared_ptr<SandboxCommand> recv;

	recv = send_request(command);
	if(!recv.get()){
		perror("Can\'t get root dir");
		exit(-1);
	}

	if(recv->get_args_size() != 1){
		perror("Can\'t get root dir");
		exit(-1);
	}

	m_root_dir = recv->get_arg_at(0);

	scmp_filter_ctx ctx;
	ctx = seccomp_init(SCMP_ACT_KILL);
	seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(socket), 3,
						SCMP_A0(SCMP_CMP_EQ, AF_UNIX),
						SCMP_A1(SCMP_CMP_EQ, SOCK_STREAM),
						SCMP_A2(SCMP_CMP_EQ, 0)
					);

	seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(connect), 0);
	seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(close), 0);
	seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(read), 0);
	seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(write), 0);
	seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(rt_sigprocmask), 0);
	seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(exit_group), 0);
	seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(getpid), 0);
	seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(mprotect), 0);
	seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(shmget), 0);
	seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(shmdt), 0);
	seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(shmctl), 0);
	seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(shmat), 0);
	seccomp_load(ctx);
}

shared_ptr<Shmem> SandboxAPI::open_file(const char *file_name, const char *mode)
{
	string shmem_key;
	size_t size;
	size_t page_size;
	key_t shm_key;
	shared_ptr<Shmem> shmem;
	shared_ptr<SandboxCommand> command;
	shared_ptr<SandboxCommand> recv;
	string str_mode = string(mode);

	if(strncmp(mode, "r", 1) && strncmp(mode, "rw", 2) && strncmp(mode, "w", 1)){
		perror("open_file(): Invalid mode");
		return shared_ptr<Shmem>(nullptr);
	}

	if(strstr(file_name, "../") || strstr(file_name, "..")){
		perror("open_file(): Invalid file_name");
		close(m_sock_fd);
		m_sock_fd = -1;
		return shared_ptr<Shmem>(nullptr);
	}

	command = make_shared<SandboxCommand>(OPEN_FILE, 0);
	command->set_argument_at(0, string(file_name));
	command->set_argument_at(1, string(mode));

	recv = send_request(command);
	if(!recv){
		perror("open_file(): recv data error");
		close(m_sock_fd);
		m_sock_fd = -1;
		return shared_ptr<Shmem>(nullptr);
	}

	if((int64_t)recv->get_header() == -1 || recv->get_args_size() != 4){
		printf("open_file(): %s\n", recv->get_arg_at(0).c_str());
		close(m_sock_fd);
		m_sock_fd = -1;
		return shared_ptr<Shmem>(nullptr);
	}

	shmem_key = recv->get_arg_at(0);
	size = strtoul(recv->get_arg_at(1).c_str(), NULL, 0);
	page_size = strtoul(recv->get_arg_at(2).c_str(), NULL, 0);
	shm_key = (key_t)strtoul(recv->get_arg_at(3).c_str(), NULL, 0);

	shmem = make_shared<Shmem>(shm_key, 0666, size);
	shmem->set_file_mode(str_mode);
	shmem->set_handle(recv->get_header());

	return shmem;
}

bool SandboxAPI::close_file(shared_ptr<Shmem> shmem)
{
	char buf[256];
	shared_ptr<SandboxCommand> command;
	shared_ptr<SandboxCommand> recv;

	if(!shmem) return false;;

	command = make_shared<SandboxCommand>(CLOSE_FILE, shmem->get_handle());
	command->set_argument_at(0, shmem->get_file_mode());
	snprintf(buf, 512, "%ld", shmem->get_offset());
	command->set_argument_at(1, string(buf, strlen(buf)));

	recv = send_request(command);
	if(!recv){
		perror("close_file(): recv data error");
		close(m_sock_fd);
		m_sock_fd = -1;
		return false;
	}

	if((int64_t)recv->get_header() == -1){
		printf("close_file(): %s\n", recv->get_arg_at(0).c_str());
		close(m_sock_fd);
		m_sock_fd = -1;
		return false;
	}

	return true;
}

bool SandboxAPI::fflush(shared_ptr<Shmem> shmem)
{
	char buf[128];
	shared_ptr<SandboxCommand> command;
	shared_ptr<SandboxCommand> recv;

	command = make_shared<SandboxCommand>(FLUSH_FILE, shmem->get_handle());
	command->set_argument_at(0, shmem->get_file_mode());
	snprintf(buf, 128, "%ld", shmem->get_offset());
	command->set_argument_at(1, string(buf, strlen(buf)));

	recv = send_request(command);
	if(!recv){
		perror("fflush(): recv data error");
		close(m_sock_fd);
		m_sock_fd = -1;
		return false;
	}

	if((int64_t)recv->get_header() < 0){
		printf("fflush(): %s\n", recv->get_arg_at(0).c_str());
		close(m_sock_fd);
		m_sock_fd = -1;
		return false;
	}

	return true;
}

shared_ptr<Shmem> SandboxAPI::extend_memory(shared_ptr<Shmem> old_shmem, size_t new_size)
{
	shared_ptr<SandboxCommand> command;
	shared_ptr<SandboxCommand> recv;
	char buf[512] = {0};
	shared_ptr<Shmem> new_shmem;
	uint64_t ret_header;
	string save_mode;

	if(!old_shmem){
		return shared_ptr<Shmem>(nullptr);
	}

	if(old_shmem->get_page_size() > new_size){
		return old_shmem;
	}

	command = make_shared<SandboxCommand>(RESIZE_SHMEM, (uint64_t)old_shmem->get_handle());

	snprintf(buf, 512, "%ld", new_size);
	command->set_argument_at(0, string(buf));

	recv = send_request(command);
	if(!recv){
		perror("close_file(): recv data error");
		close(m_sock_fd);
		m_sock_fd = -1;
		return shared_ptr<Shmem>(nullptr);
	}

	ret_header = recv->get_header();
	if((int64_t)ret_header < 0){
		printf("extend_memory error: %s\n", recv->get_arg_at(0).c_str());
		return shared_ptr<Shmem>(nullptr);
	}

	if(!ret_header){
		// shmem is not changed
		return old_shmem;
	}

	new_shmem = make_shared<Shmem>(recv->get_header(), 0666, new_size);
	new_shmem->set_shared_key(recv->get_arg_at(0));
	new_shmem->set_handle(old_shmem->get_handle());
	save_mode = old_shmem->get_file_mode();
	new_shmem->set_file_mode(save_mode);
	new_shmem->set_offset(old_shmem->get_offset());

	return new_shmem;
}

shared_ptr<Shmem> SandboxAPI::write_to_shmem(shared_ptr<Shmem> shmem, void *in_buf, size_t buf_size)
{
	string mode;

	mode = shmem->get_file_mode();
	if(strncmp(mode.c_str(), "rw", 2) && strncmp(mode.c_str(), "w", 1)) return shmem;

	if(shmem->get_page_size() >= (buf_size + shmem->get_offset())){
		memcpy(shmem->get_cur_buffer(), in_buf, buf_size);
		shmem->update_offset(buf_size);
	} else {
		// extend memory
		shmem = extend_memory(shmem, buf_size);
		if(!shmem) return shared_ptr<Shmem>(nullptr);
		memcpy(shmem->get_cur_buffer(), in_buf, buf_size);
		shmem->update_offset(buf_size);
	}

	fflush(shmem);
	
	return shmem;
}

uint64_t SandboxAPI::attach_buffer(shared_ptr<Shmem> share_buf)
{
	shared_ptr<SandboxCommand> command, recv;
	char tmp[128];

	command = make_shared<SandboxCommand>(ATTACH_BUFFER, share_buf->get_shm_key());
	snprintf(tmp, 128, "%ld", share_buf->get_buffer_size());
	command->set_argument_at(0, string(tmp, strlen(tmp)));

	recv = send_request(command);
	if(!recv){
		perror("send_request");
		return 0;
	}

	if((int64_t)recv->get_header() == -1){
		printf("ATTACH_BUFFER: %s\n", recv->get_arg_at(0).c_str());
		return 0;
	}

	return (uint64_t)recv->get_header();
}

bool SandboxAPI::detach_buffer(uint64_t hash)
{
	shared_ptr<SandboxCommand> command, recv;

	command = make_shared<SandboxCommand>(DETACH_BUFFER, hash);

	recv = send_request(command);
	if(!recv){
		perror("send_request");
		return false;
	}

	if((int64_t)recv->get_header() == -1){
		printf("ATTACH_BUFFER: %s\n", recv->get_arg_at(0).c_str());
		return false;
	}

	return true;
}

bool SandboxAPI::commit_buffer(uint64_t hash)
{
	shared_ptr<SandboxCommand> command, recv;

	command = make_shared<SandboxCommand>(COMMIT_BUFFER, hash);
	recv = send_request(command);
	if(!recv){
		perror("send_request");
		return false;
	}

	if((int64_t)recv->get_header() == -1){
		printf("ATTACH_BUFFER: %s\n", recv->get_arg_at(0).c_str());
		return false;
	}

	return true;
}

shared_ptr<SandboxCommand> SandboxAPI::send_request(shared_ptr<SandboxCommand> command)
{
	struct sockaddr_un addr;
	char *serialize_buf;
	char *buf;
	uint32_t buf_size;
	uint32_t serialize_size;
	shared_ptr<SandboxCommand> recv_command;

	if(m_sock_fd < 0){
		// create unix socket
		addr.sun_family = AF_UNIX;
		m_sock_fd = socket(AF_UNIX, SOCK_STREAM, 0);

		strncpy(addr.sun_path, m_sock_path.c_str(), sizeof(addr.sun_path) - 1);
		if (connect(m_sock_fd, (struct sockaddr *)&addr, sizeof(addr)) == -1) {
			perror("Unable to connect to sandboxd");
			exit(-1);
		}
	}

	command->serialize(&serialize_buf, &serialize_size);

	write(m_sock_fd, &serialize_size, sizeof(serialize_size));
	write(m_sock_fd, serialize_buf, serialize_size);
	free(serialize_buf);

	read(m_sock_fd, &buf_size, sizeof(buf_size));

	if(buf_size > MAX_SIZE_PACKET){
		perror("Invalid recv size");
		return shared_ptr<SandboxCommand>(nullptr);
	}

	buf = (char *)malloc(buf_size);
	read(m_sock_fd, buf, buf_size);

	recv_command = make_shared<SandboxCommand>();
	if(!recv_command->deserialize(buf, buf_size)){
		free(buf);
		return shared_ptr<SandboxCommand>(nullptr);
	}

	free(buf);
	return recv_command;
}