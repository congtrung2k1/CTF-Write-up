#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <unistd.h>
#include <time.h>
#include <memory>
#include <algorithm>
#include <vector>
#include "sandbox_lib.h"
#include "sandbox_protocol.h"

using namespace std;

unique_ptr<SandboxAPI> api;
// char sock_path[] = "/tmp/sandbox_sock.unix";

void Hexdump(const char* data, size_t size) {
	unsigned char ascii[17];
	size_t i, j;
	ascii[16] = '\0';
	for (i = 0; i < size; ++i) {
		printf("%02X ", (unsigned char)data[i]);
		if (data[i] >= ' ' && data[i] <= '~') {
			ascii[i % 16] = (unsigned char)data[i];
		} else {
			ascii[i % 16] = '.';
		}
		if ((i+1) % 8 == 0 || i+1 == size) {
			printf(" ");
			if ((i+1) % 16 == 0) {
				printf("|  %s \n", ascii);
			} else if (i+1 == size) {
				ascii[(i+1) % 16] = '\0';
				if ((i+1) % 16 <= 8) {
					printf(" ");
				}
				for (j = (i+1) % 16; j < 16; ++j) {
					printf("   ");
				}
				printf("|  %s \n", ascii);
			}
		}
	}
}

class User
{
	string m_username;
	string m_password;

	char *m_secret_data;
	uint32_t m_size;

public:
	User() : m_secret_data(nullptr), m_size(0) {};
	User(const char *username, const char *password);
	User(string &username, string& password);
	~User();

	virtual void set_secret(char *pbuf, uint32_t size);
	virtual string save();
	virtual bool load(const char *file_name);
	virtual string get_username() { return m_username; };
	virtual string get_password() { return m_password; };

	virtual char* get_secret() { return m_secret_data; };
	virtual uint32_t get_secret_size() { return m_size; };

	virtual bool is_valid(const char *username, const char *password);
	virtual bool is_valid(string username, string password);
};

User::User(const char *username, const char *password)
{
	m_username = string(username);
	m_password = string(password);
}

User::User(string &username, string& password)
{
	m_username = username;
	m_password = password;
}

User::~User()
{
	if(m_secret_data){
		free(m_secret_data);
	}
}

void User::set_secret(char *pbuf, uint32_t size)
{
	if(m_secret_data) free(m_secret_data);

	m_secret_data = pbuf;
	m_size = size;
}

string User::save()
{
	shared_ptr<Shmem> pfile;
	string save_path;
	char buf[1024]={0};
	string ret = "";

	if(!m_secret_data) return ret;
	if(!m_size) return ret;

	snprintf(buf, 1024, "%s_%d_%d", m_username.c_str(), (uint32_t)time(0), getpid());
	save_path = string(buf, strlen(buf));

	pfile = api->open_file(save_path.c_str(), "w");
	if(!pfile){
		return ret;
	}

	api->write_to_shmem(pfile, m_secret_data, m_size);
	api->close_file(pfile);

	return save_path;
}

bool User::load(const char *file_name)
{
	shared_ptr<Shmem> pfile;

	if(m_secret_data){
		free(m_secret_data);
		m_secret_data = nullptr;
	}

	pfile = api->open_file(file_name, "r");
	if(!pfile){
		return false;
	}

	m_size = pfile->get_buffer_size();
	m_secret_data = (char *)malloc(m_size);
	memcpy(m_secret_data, pfile->get_buffer(), m_size);

	api->close_file(pfile);
	return true;
}


bool User::is_valid(const char *username, const char *password)
{
	string user, passwd;
	user = string(username);
	passwd = string(password);
	return is_valid(user, passwd);
}

bool User::is_valid(string username, string password)
{
	if(!m_username.compare(username) && !m_password.compare(password)) return true;
	return false;
}

vector<shared_ptr<User>> active_users;

void read_buf(char *buf, uint32_t size)
{
	unsigned char c;
	uint32_t i = 0;

	while(i < size){
		read(0, &c, 1);
		if(c == '\n'){
			break;
		}
		buf[i++] = c;
	}
}

uint32_t read_uint32()
{
	char buf[32] = {0};
	read_buf(buf, 31);

	return (uint32_t)strtoul(buf, NULL, 0);
}

void do_active_user(shared_ptr<User> active_user)
{
	uint32_t op;
	bool stop = false;
	char *pbuf;
	char load_file[1024] = {0};
	uint32_t size;
	string your_file_name;
	int idx;

	while(!stop){
		printf("======= Hello: %s =======\n", active_user->get_username().c_str());
		printf("1. Attach your secret\n");
		printf("2. Save your data\n");
		printf("3. Read your secret\n");
		printf("4. Load your secret\n");
		printf("5. Destroy your account\n");
		printf("6. Logout\n");
		printf(">>");

		op = read_uint32();
		
		switch(op){
			case 1:
				printf("Size: ");
				size = read_uint32();
				printf("Data: ");
				if(size > 0x1000) size = 0xFFF;

				if(size > active_user->get_secret_size()){
					pbuf = (char *)malloc(size);
					active_user->set_secret(pbuf, size);
				}else{
					pbuf = active_user->get_secret();
				}

				read_buf(pbuf, size);
				printf("Done.\n");
				break;
			case 2:
				your_file_name = active_user->save();
				if(your_file_name.length()){
					printf("Saving secret to : %s\n", your_file_name.c_str());
				} else {
					printf("You have to attach your secret first\n");
				}
				break;
			case 3:
				if(active_user->get_secret()){
					printf("Your secret:\n");
					Hexdump(active_user->get_secret(), active_user->get_secret_size());
				} else {
					puts("You have no secret");
				}
				break;
			case 4:
				printf("File name: ");
				read_buf(load_file, 1024);
				if(!active_user->load(load_file)){
					printf("Load file %s is failed\n", load_file);
				} else {
					printf("Load file %s is OK\n", load_file);
				}
				break;
			case 5:
				stop = true;
				idx = -1;
				for(uint32_t i = 0; i < active_users.size(); i++){
					if(active_users[i]->is_valid(active_user->get_username(), active_user->get_password())){
						idx = i;
						break;
					}
				}

				if(idx > -1){
					active_users.erase(active_users.begin() + idx);
				}

				printf("Logout...\n");
				break;
			case 6:
				stop = true;
				break;
			default:
				printf("Invalid option\n");
				break;
		}

	}
	
}

int sub_main()
{
	uint32_t op;
	char buf[512] = {0};
	string username;
	string password;
	shared_ptr<User> active_user(nullptr);
	shared_ptr<User> new_user;
	bool stop = false;

	while(!stop)
	{
		printf("======= Secret Keeper =======\n");
		printf("1. Register\n");
		printf("2. Login\n");
		printf("3. Exit\n");
		printf(">> ");
		op = read_uint32();

		switch(op){
			case 1:
				printf("Username:");
				memset(buf, 0, 64);
				read_buf(buf, 64);
				username = string(buf, strlen(buf));
				printf("Password:");
				memset(buf, 0, 64);
				read_buf(buf, 64);
				password = string(buf, strlen(buf));

				new_user = make_shared<User>(username, password);
				active_users.push_back(new_user);
				break;
			case 2:
				if(!active_users.size()){
					printf("System have no accounts, please register first\n");
					break;
				}

				printf("Username:");
				memset(buf, 0, 64);
				read_buf(buf, 64);
				username = string(buf, strlen(buf));
				printf("Password:");
				memset(buf, 0, 64);
				read_buf(buf, 64);
				password = string(buf, strlen(buf));

				active_user = shared_ptr<User>(nullptr);
				for(uint32_t i = 0; i < active_users.size(); i++){
					if(active_users[i]->is_valid(username, password)){
						active_user = active_users[i];
						break;
					}
				}

				if(!active_user){
					printf("Invalid username or password\n");
					active_user = shared_ptr<User>(nullptr);
					break;
				}

				do_active_user(active_user);
				break;

			case 3:
				stop = true;
				break;
			default:
				puts("Invalid option");
				break;
		}
	}

	return 0;
}

int main()
{
	char sock_path[512];

	setvbuf(stdin, NULL , _IONBF , 0);
	setvbuf(stdout, NULL , _IONBF , 0);

	snprintf(sock_path, 512, "/tmp/sandbox_sock_%d.unix", getppid());

	printf("Waiting for sandboxd... ");
	sleep(1);
	printf("OK ready to go\n");

	api = make_unique<SandboxAPI>(sock_path);
	api->init_sandbox();
	return sub_main();
}